#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

curl -fL \
  https://github.com/mattermost-community/mattermost-plugin-jitsi/releases/download/v2.1.0/jitsi-2.1.0.tar.gz \
  -o jitsi-2.1.0.tar.gz

echo "Downloaded: jitsi-2.1.0.tar.gz"
echo "Upload in Mattermost: System Console -> Plugins -> Plugin Management -> Upload Plugin"
