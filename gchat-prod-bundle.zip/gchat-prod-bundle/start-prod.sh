#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

[ -f .env.prod ] || { echo ".env.prod is missing. Run ./configure-prod.sh first."; exit 1; }
grep -q 'CHANGE_ME' .env.prod && { echo ".env.prod contains placeholders."; exit 1; }

docker compose --env-file .env.prod -f compose.prod.yml config >/dev/null
docker compose --env-file .env.prod -f compose.prod.yml pull
docker compose --env-file .env.prod -f compose.prod.yml up -d

echo
docker compose --env-file .env.prod -f compose.prod.yml ps
