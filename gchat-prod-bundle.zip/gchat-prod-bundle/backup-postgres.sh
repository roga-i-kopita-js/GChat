#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env.prod ] || { echo ".env.prod is missing."; exit 1; }

set -a
source ./.env.prod
set +a

mkdir -p backups
STAMP="$(date +%F-%H%M%S)"
FILE="backups/mattermost-${STAMP}.sql.gz"

docker compose --env-file .env.prod -f compose.prod.yml exec -T postgres \
  pg_dump -U "${POSTGRES_USER}" "${POSTGRES_DB}" \
  | gzip > "${FILE}"

echo "Backup created: ${FILE}"
