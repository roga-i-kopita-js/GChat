#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v openssl >/dev/null 2>&1; then
  echo "Install openssl first: sudo apt install -y openssl"
  exit 1
fi

PUBLIC_IP="${1:-}"
MATTERMOST_DOMAIN="${2:-}"
JITSI_DOMAIN="${3:-}"
ACME_EMAIL="${4:-}"

[ -n "$PUBLIC_IP" ] || read -r -p "Public VPS IP: " PUBLIC_IP
[ -n "$MATTERMOST_DOMAIN" ] || read -r -p "Mattermost domain: " MATTERMOST_DOMAIN
[ -n "$JITSI_DOMAIN" ] || read -r -p "Jitsi domain: " JITSI_DOMAIN
[ -n "$ACME_EMAIL" ] || read -r -p "Email for Let's Encrypt: " ACME_EMAIL

if [ -f .env.prod ]; then
  read -r -p ".env.prod already exists. Overwrite and regenerate secrets? [y/N] " ANSWER
  [[ "$ANSWER" =~ ^[Yy]$ ]] || { echo "Cancelled."; exit 0; }
fi

POSTGRES_PASSWORD="$(openssl rand -hex 32)"
JICOFO_AUTH_PASSWORD="$(openssl rand -hex 32)"
JVB_AUTH_PASSWORD="$(openssl rand -hex 32)"
JITSI_JWT_APP_SECRET="$(openssl rand -hex 32)"

cat > .env.prod <<EOF
TZ=Europe/Moscow
PUBLIC_IP=${PUBLIC_IP}
MATTERMOST_DOMAIN=${MATTERMOST_DOMAIN}
JITSI_DOMAIN=${JITSI_DOMAIN}
ACME_EMAIL=${ACME_EMAIL}

MATTERMOST_IMAGE_TAG=11.7.0
MATTERMOST_ENABLE_SIGNUP_WITH_EMAIL=true

POSTGRES_DB=mattermost
POSTGRES_USER=mmuser
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}

JITSI_IMAGE_VERSION=stable-10978
JVB_PORT=10000

XMPP_DOMAIN=meet.jitsi
XMPP_AUTH_DOMAIN=auth.meet.jitsi
XMPP_GUEST_DOMAIN=guest.meet.jitsi
XMPP_MUC_DOMAIN=muc.meet.jitsi
XMPP_INTERNAL_MUC_DOMAIN=internal-muc.meet.jitsi
XMPP_HIDDEN_DOMAIN=recorder.meet.jitsi

JICOFO_AUTH_PASSWORD=${JICOFO_AUTH_PASSWORD}
JVB_AUTH_PASSWORD=${JVB_AUTH_PASSWORD}

JITSI_JWT_APP_ID=mattermost
JITSI_JWT_APP_SECRET=${JITSI_JWT_APP_SECRET}
EOF

chmod 600 .env.prod

echo
echo ".env.prod created."
echo "Mattermost URL: https://${MATTERMOST_DOMAIN}"
echo "Jitsi URL:      https://${JITSI_DOMAIN}"
echo "JWT App ID:     mattermost"
echo "JWT App Secret: ${JITSI_JWT_APP_SECRET}"
echo
echo "Save the JWT secret securely. You will enter it in the Mattermost Jitsi plugin settings."
