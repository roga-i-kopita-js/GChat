# GChat production bundle

Single VPS deployment for a small private Mattermost installation with PostgreSQL, built-in Mattermost Calls, self-hosted Jitsi Meet with JWT authentication, and Caddy with automatic Let's Encrypt certificates.

## Before start

Point two A records to the VPS public IP:

```text
chat.example.ru -> VPS IP
meet.example.ru -> VPS IP
```

Open Yandex Cloud inbound ports:

| Port | Protocol | Source |
|---:|---|---|
| 22 | TCP | your IP /32 |
| 80 | TCP | 0.0.0.0/0 |
| 443 | TCP | 0.0.0.0/0 |
| 8443 | TCP | 0.0.0.0/0 |
| 8443 | UDP | 0.0.0.0/0 |
| 10000 | UDP | 0.0.0.0/0 |

Outbound:

```text
Any protocol, ports 0-65535, CIDR 0.0.0.0/0
```

## Upload from Mac

```bash
scp -i ./ignore/ssh-key-1780773492383 \
  gchat-prod-bundle.zip \
  a-glotov@158.160.170.141:~/
```

## Unpack on VPS

```bash
sudo apt install -y unzip openssl curl
unzip ~/gchat-prod-bundle.zip -d ~/
cd ~/gchat-prod-bundle
chmod +x *.sh
```

## Generate `.env.prod`

```bash
./configure-prod.sh \
  158.160.170.141 \
  chat.example.ru \
  meet.example.ru \
  admin@example.ru
```

Replace domains and email with real values.

## Start

```bash
./start-prod.sh
```

Check:

```bash
docker compose --env-file .env.prod -f compose.prod.yml ps
./logs-prod.sh
./logs-prod.sh caddy
```

## Bootstrap Mattermost

Open your Mattermost domain and create the first administrator. Then disable public signup:

```bash
nano .env.prod
```

Change:

```env
MATTERMOST_ENABLE_SIGNUP_WITH_EMAIL=false
```

Apply:

```bash
docker compose --env-file .env.prod -f compose.prod.yml up -d --force-recreate mattermost
```

## Configure Jitsi plugin

Download:

```bash
./download-jitsi-plugin.sh
```

Upload `jitsi-2.1.0.tar.gz` in:

```text
System Console -> Plugins -> Plugin Management -> Upload Plugin
```

Configure:

```text
System Console -> Plugins -> Jitsi

Enable Plugin: true
Jitsi Server URL: https://meet.example.ru
Embed Jitsi video inside Mattermost: false
Use JWT Authentication for Jitsi: true
App ID: mattermost
App Secret: value of JITSI_JWT_APP_SECRET from .env.prod
Meeting Link Expiry Time: 10
Jitsi Meeting Names: UUID
```

Read secret:

```bash
grep '^JITSI_JWT_APP_SECRET=' .env.prod
```

## Backup

```bash
./backup-postgres.sh
```

## Stop

```bash
./stop-prod.sh
```

Never use `docker compose down -v` unless you intentionally want to delete persistent data.
